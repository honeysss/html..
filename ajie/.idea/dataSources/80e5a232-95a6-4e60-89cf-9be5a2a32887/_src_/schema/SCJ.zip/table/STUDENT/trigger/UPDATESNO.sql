CREATE TRIGGER UPDATESNO
AFTER UPDATE
  ON STUDENT
FOR EACH ROW
  BEGIN
    update score set sno = :new.sno where sno = :old.sno;
  END;
/
