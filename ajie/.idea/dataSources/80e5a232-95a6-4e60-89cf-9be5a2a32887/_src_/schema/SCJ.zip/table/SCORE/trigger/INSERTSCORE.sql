CREATE TRIGGER INSERTSCORE
AFTER INSERT
  ON SCORE
  DECLARE
    v_str VARCHAR(20) := '正在插入数据';
    BEGIN
    dbms_output.put_line(v_str);
  END;
/
